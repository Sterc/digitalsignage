<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 2.0.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 3.0.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 2.0.0
Released: 2026-10-23
----------------------
- Moved to MODX 3 only
- Added an API
- Fixed broken media URLs (\'test\' in the path)

----------------------
Version: 1.3.1
Released: 2026-05-13
----------------------
- Add bulk depublish button for slides
- Fix modified_on date not being set when creating a new slide

----------------------
Version: 1.3.0
Released: 2025-06-04
----------------------
- Add bulk removal for slides

----------------------
Version: 1.2.10
Released: 2025-06-04
----------------------
- Fix migrating issue in installer
- Fix getting data for slideType

----------------------
Version: 1.2.9
Released: 2025-04-23
----------------------
- Bugfixes for MODX 3.0.0
- Updated old packages that are used in the template
- Fixed PHP Warnings

----------------------
Version: 1.2.8
Released: 2022-05-20
----------------------
- Add internal video for Media slide
- Fix date and time formatting if manager_date_format was changed
- Fix error on broadcast duplicate
- Fix entire day for players schedule

----------------------
Version: 1.2.7
Released: 2021-09-17
----------------------
- Add preview for slides

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'requires' => 
    array (
      'modx' => '>=3.0.0',
      'php' => '>=8.1',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '888aecb6f202f59d05f3d3955f295adb',
      'native_key' => 'digitalsignage',
      'filename' => 'MODX/Revolution/modNamespace/c86121218d6de7cf12d7602706688477.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9cb05ee983d7741b420d391fb9859334',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'MODX/Revolution/modSystemSetting/2da72d670f0542d954a8898df4b938f7.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e067a431a73f969303656379069419a9',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'MODX/Revolution/modSystemSetting/ae09058d2a9b2f3744592d4efbf41198.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fa99c3d6d2b73c7f0c52c031dad6e825',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'MODX/Revolution/modSystemSetting/a0582a143e22a0e6fe42789ab248338f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb9c3e8cda0c9baae02bac82b4fb82a0',
      'native_key' => 'digitalsignage.context',
      'filename' => 'MODX/Revolution/modSystemSetting/06619e00dae1bd0a76cb3a6bf98d7634.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '36a397e548d27fe8c49214f55ac535c3',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/a2f4bc980cf3312bc2447b1e59db534a.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ce6551516d5f9952601218be9541794',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/c3cde7eb272fbd0fa9630d520da2bdf5.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a8866dde63d7126e0cf5ba5b39d77c0',
      'native_key' => 'digitalsignage.mcp_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/2bbc63900a5321dd449aa2bd84fcadc2.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02bc693d2449c297710e994d6fb2118c',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/2397c7a63421052d7cb655e6b5dbb723.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '006f86216706b0a88919ad53092790ab',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'MODX/Revolution/modSystemSetting/7c7eaa781cbe5e530b995bb0fb1e36b1.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1b872131ad8aa2aa75c8c702857a2618',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'MODX/Revolution/modSystemSetting/37912dc7a37185ae9aba8b6c11e0cef3.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2a70a8b567ae062223c0b4c36ccc103c',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/25908bac1f5f7cadc9f1a0bc0dace69c.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '05eae11908ec7941f2ee0b9bef7a383e',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'MODX/Revolution/modSystemSetting/28c2d47096962699a24cb38d886f6230.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1eb460a5cff81e86e7f63e37fb2b5617',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'MODX/Revolution/modSystemSetting/8a564b19ed1483468f5cfb43b302a2a0.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74052583759486d15311dfe6e01ff126',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/7461aefbacbbe19f155c7b4b3774c45c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '094f32dedc2f8346998612c6982bd8ef',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'MODX/Revolution/modSystemSetting/82fec09269f973a91f36092a00027b4c.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '447dca114e7597916b4a6fbfdd39b078',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'MODX/Revolution/modSystemSetting/aa3e5cce8861792b14cd56df01af8853.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '966ddd071a73484491bb60a978734a0d',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'MODX/Revolution/modSystemSetting/999b639b0de3e0c4ebfcb9a1c50bf484.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'edc4e02506de7c29a4c3b546cddb70b2',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'MODX/Revolution/modSystemSetting/62c05b73332f8011c93f725ee3535d1d.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3f209987ddfde848d9e5e84b03822d74',
      'native_key' => '3f209987ddfde848d9e5e84b03822d74',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/5e1d58c2705a3eebf50b1aab33492e4d.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '5665257f1b0ef679652f962bdac30a8f',
      'native_key' => 'digitalsignage',
      'filename' => 'MODX/Revolution/modMenu/f90553c8f376a20cb2d7dc24c1f5c822.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a97185020548c136714c83d01e5fffe2',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/6ee3cff40b0c86ab8f6d4fec5151a22f.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3addb2bde2234fd08b7c69e84810f9bf',
      'native_key' => '3addb2bde2234fd08b7c69e84810f9bf',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f998c7e6f696cf20c1731cfa0e7e4784.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'c2775e38d7969fabe0db93a7e5af9726',
      'native_key' => 'c2775e38d7969fabe0db93a7e5af9726',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/9ed053203e7cecfb6d1799485cfa51f6.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '394e2237858b789534d2b0813b828f4c',
      'native_key' => '394e2237858b789534d2b0813b828f4c',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f3b81528feae971b17781af35ea52a1b.vehicle',
    ),
  ),
);