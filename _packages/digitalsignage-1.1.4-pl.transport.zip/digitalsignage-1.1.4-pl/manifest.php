<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.4
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.4-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4272a0b23b146fc6c43ae7c7c6ff87a4',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/5ed2e2595e3bb7cff8735bee60c5b972.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3bec06d0a08fd64062f89fd7307e9fd2',
      'native_key' => NULL,
      'filename' => 'modCategory/c43e5d2669cb512dd83ee7a5eafcabc7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '911f81afa566da82ba6898aa723bfe3a',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/554979068d4b5bda06d3dbf5321e2a93.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4f5b5feb6350cabd9047c965fd05c32',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/5904853d1bef3e7f722d78881bbdc9ef.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4b12a54dce02b7541d2d599481117a4',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/ca424cc81eb742ee1459286344a1b93d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '933004310d8abbc474cb472799205acb',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/72e07b12cfe9ae275428d77ae93dbf20.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fbc1f35e0d9686f6f3e7e4c3b7168b6',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/1328d8bb3774940062599d52105e46dc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '014791c31ea8e2aa46f08cae31e35bd5',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/e92bca695c5119d4d0038fbb45b83524.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0674975107c53fcd9812f590ee86bc4f',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/12230bf84c6f77e02aa9464c8e35bb6a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f528cdf8a04a5d0f6c6304c74f6a7b77',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/d4679f98dedabaea96a8337d08ca108a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02736492da61b0a6ed74296483666a91',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/91317f54de5da8f95b3284bbe95ee1f9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '548fe47523997233e14a983ff1fabedf',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/b07ee98465de92be8d697b7dbbe85ee0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c747a093acf12710360110bdcee51928',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/e3b695273997e278955387e5a11875eb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe564280f6f4364185ec36a3ba9209b',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/58384c003e958a0792d313004a88440c.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);