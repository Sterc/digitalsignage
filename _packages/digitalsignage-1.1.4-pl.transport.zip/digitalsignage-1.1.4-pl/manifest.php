<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.4
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.4-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '64284636b7e70f6c8e826fcfda702c11',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/1787e877b66f7fa9850594eba8a08ad0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a2991ff8e43555b03a4db1992cd11b9c',
      'native_key' => 'a2991ff8e43555b03a4db1992cd11b9c',
      'filename' => 'xPDOFileVehicle/cd0b58fc3b7184f3bd447bfa287ac2b1.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'encryptedVehicle',
      'class' => 'modCategory',
      'guid' => '8a4f39369da3d9484ddac1bd1c37e26c',
      'native_key' => NULL,
      'filename' => 'modCategory/2cd1d1a94f2b7ed10796fcce84ed140f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '79324d9ad055aeb5434d71d17a3b5b08',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/8a6e1744ae20cc36a2799a145af27713.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe3b174cff4817f3468dfddc373c0cce',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/aa412b954ead31c5a6d622fdfef4c770.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '115356dadde07cb803c63912f1cc04a4',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/9bc4de8a381941153603c58d91077dce.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a9f864097c39e4884837af357fa2650',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/dae1d76ab22a9acd2321e9bf323bd3b1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df548b4aec29276796fe599e6031d916',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/e258ea9a2337b76fa781f82bc9e1f31f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75326abc71cf81ef79ef9c9be1e136b6',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/bb7a5968f2b9df029217d037069a7a84.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21ffafe98b1557faad82d615d771d069',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/7ac2228c1d5a88fd3557a55818975026.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38293016b44b638ab946f198e0493920',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/62ed92bce4d3a9809ea2be4fdbb9a7d3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8dd586447659ca3bfa83fd99c0f43b1',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/37ae9489e338c95bfae85b65ef6b1ab2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d33d6b6333459d3d4c1b73bdb9abff7',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/e6bbd3f6d186510cfa25d79a99fa3c56.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08f8bab768058100d0edeb9f942e7aa5',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/1efc6223f1bccb77a548c0fd09a1dec6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35fcfa912da4c4ec960d0398b2139ff4',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/ea1df8f77862f701aa480a2c308fe9e5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'be9824dae1a9bc64cd8c24298799d843',
      'native_key' => 'be9824dae1a9bc64cd8c24298799d843',
      'filename' => 'xPDOScriptVehicle/ee98fd26568147c7f6547ed9f5974083.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);