<?php

    require_once dirname(__DIR__) . '/digitalsignageplayers.class.php';

    class DigitalSignagePlayers_mysql extends DigitalSignagePlayers
    {
    }

?>