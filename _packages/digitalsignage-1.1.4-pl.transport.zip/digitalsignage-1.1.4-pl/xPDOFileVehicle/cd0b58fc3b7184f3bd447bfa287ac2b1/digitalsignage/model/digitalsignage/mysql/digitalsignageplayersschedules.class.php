<?php

    require_once dirname(__DIR__) . '/digitalsignageplayersschedules.class.php';

    class DigitalSignagePlayersSchedules_mysql extends DigitalSignagePlayersSchedules
    {
    }

?>