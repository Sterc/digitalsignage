<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.5-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '05f88cd18adc9c21d0c6ceb8db6236a8',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/2961117c88f06eef2a952225de2dfcb6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd620e4f61dcceed320233689e932dac',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/f4d387ee99e6d36358047ad352b72c1c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a710e148509525475a3d7e3099cf557a',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/fef2a43be06a2c5429aa10fa993ad2b9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c73246e727f4900f0d7a1db90f70eba2',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/09d3a00468e197e2ceb5163007d6eec0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '396506e217663e341447743f99af1ebc',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/658f2d539b80589ea7c57d0f6e07a0e1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1aa5edf620c4802690c0b906248c404a',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/afc8f88fdf2103f7734518b9ae3eb1d0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1c74486e0523b85bf9fec802d2e5d2dc',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/c3fcf88ba1a52f38f64e7ad6ff882fc4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0617761f5f6ef0d7cf2164d724761f48',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/2db228e6a9b271e787e404c2493d46ea.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64d2bf60553649d79d90c07a079ba56e',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/f73bd316722c33f51002ed784d7d813a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2292f96c4ea2f85a4c93375592432f32',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/092b4ca6a926eedfa9e057b3080059dd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'defb657cad2ec2c356b52de1e8f71a55',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/bfda8a5a6690f1c61e324ea8407b704d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16284ce77dda93875728b30385f8d88a',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/effe4cb28cc6f74d2a68dab2a624d76d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '827606a7a15918a106791973205f9273',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/bb5cc61198bf2ba969a22e822eb7954c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '646d76474a65fbce8fdf89c202720fe6',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/cd590c336bd8da23e1d081a62ff66077.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33e18305f8beb5917bda5d5120e42c70',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/a7272f89d5c03cf51fb58f4ca6f4dde0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f763d7bf3d249063c9003d58052a2a78',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/a490a1e47d38216b48174e03b5e51960.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f471332ff910a93e0d55ae27d2c8e4f1',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/1125d2a51123546d69f20821069ba9dd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe6afd0b91aece328c4115fc7dcf094c',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/d2465623b83f5fdf70e3682a79d4d0a1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd02119a7fe0c2ec1196e3275765e0cfc',
      'native_key' => NULL,
      'filename' => 'modCategory/d2bed2361aaeffff7539c17d819ab94a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'af4f3db858a795f3de43f5ec9e715c06',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/34f38cd7f993206ef83211e2b3ecaf39.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);