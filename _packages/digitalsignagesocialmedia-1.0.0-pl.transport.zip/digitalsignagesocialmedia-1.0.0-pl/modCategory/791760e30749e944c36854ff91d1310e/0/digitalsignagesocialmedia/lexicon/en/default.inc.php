<?php

    $_lang['digitalsignagesocialmedia']                                     = 'Digital Signage Social Media';
    $_lang['digitalsignagesocialmedia.desc']                                = '';

    $_lang['area_digitalsignagesocialmedia']                                = 'Digital Signage Social Media';

    $_lang['setting_digitalsignagesocialmedia.facebook_app_id']             = 'Facebook APP ID';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_id_desc']        = '';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_secret']         = 'Facebook Secret';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_secret_desc']    = '';
    $_lang['setting_digitalsignagesocialmedia.facebook_page']               = 'Facebook Page';
    $_lang['setting_digitalsignagesocialmedia.facebook_page_desc']          = '';

?>