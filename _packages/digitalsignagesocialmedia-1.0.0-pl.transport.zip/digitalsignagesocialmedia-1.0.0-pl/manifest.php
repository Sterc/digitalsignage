<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'digitalsignagesocialmedia-1.0.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd6baec5eaa3fdd22437b463f013590d8',
      'native_key' => 'digitalsignagesocialmedia',
      'filename' => 'modNamespace/5bad51c4c35a1cff84845e004e0481c4.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ee1ae7668172708ffa8917df54faba5',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_id',
      'filename' => 'modSystemSetting/fe408709bcf9d04c13bbca3fa9986c8c.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddd83a9de92fe880cc5267e6fc3cc08a',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_secret',
      'filename' => 'modSystemSetting/a70b3d99a86fbf6d3e0104ff21051be9.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bff105161061e917a695ff9ca402a57',
      'native_key' => 'digitalsignagesocialmedia.facebook_page',
      'filename' => 'modSystemSetting/b3bc23be02e3c7888ecf760f9b1dc5dc.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bc98f07c911e5b0f0ddf1bfe334e1273',
      'native_key' => NULL,
      'filename' => 'modCategory/791760e30749e944c36854ff91d1310e.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
  ),
);