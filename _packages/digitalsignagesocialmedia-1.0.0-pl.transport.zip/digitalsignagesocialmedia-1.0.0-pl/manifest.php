<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'digitalsignagesocialmedia-1.0.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e89626122cd765e090a245ab2b86635c',
      'native_key' => 'digitalsignagesocialmedia',
      'filename' => 'modNamespace/bd0ce07713ea80f9a3da8a53c37076ac.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbf217e4d9143fd8798a0e57b5eb71f4',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_id',
      'filename' => 'modSystemSetting/c6c0a2ac6ad75db7dfed1a5b7a612c09.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb722fa2bc0b3b1156983ebe166892d',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_secret',
      'filename' => 'modSystemSetting/5cb72702da60a1ac4f2f1a9449f39d7b.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0b332f3920aaaa644d9cf97d0d156cf',
      'native_key' => 'digitalsignagesocialmedia.facebook_page',
      'filename' => 'modSystemSetting/0fbf547c28da6a3287aea2dbf24b7972.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dc6b6a923b384612dbd66e7cafce73b0',
      'native_key' => NULL,
      'filename' => 'modCategory/b4f6318d0ea6381e261debf0d14f9ef5.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
  ),
);