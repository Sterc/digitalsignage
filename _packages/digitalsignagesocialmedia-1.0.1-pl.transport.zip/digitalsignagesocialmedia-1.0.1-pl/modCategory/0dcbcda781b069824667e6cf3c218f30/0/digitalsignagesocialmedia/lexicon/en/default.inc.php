<?php

    $_lang['digitalsignagesocialmedia']                                         = 'Digital Signage Social Media';
    $_lang['digitalsignagesocialmedia.desc']                                    = '';

    $_lang['area_digitalsignagesocialmedia']                                    = 'Digital Signage Social Media';

    $_lang['setting_digitalsignagesocialmedia.facebook_app_id']                 = 'Facebook APP ID';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_id_desc']            = '';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_secret']             = 'Facebook Secret';
    $_lang['setting_digitalsignagesocialmedia.facebook_app_secret_desc']        = '';
    $_lang['setting_digitalsignagesocialmedia.facebook_page']                   = 'Facebook Page';
    $_lang['setting_digitalsignagesocialmedia.facebook_page_desc']              = '';

    $_lang['setting_digitalsignagesocialmedia.twitter_consumer_key']            = 'Twitter Consumer Key';
    $_lang['setting_digitalsignagesocialmedia.twitter_consumer_key_desc']       = '';
    $_lang['setting_digitalsignagesocialmedia.twitter_consumer_secret']         = 'Twitter Consumer Secret';
    $_lang['setting_digitalsignagesocialmedia.twitter_consumer_secret_desc']    = '';
    $_lang['setting_digitalsignagesocialmedia.twitter_token']                   = 'Twitter Token';
    $_lang['setting_digitalsignagesocialmedia.twitter_token_desc']              = '';
    $_lang['setting_digitalsignagesocialmedia.twitter_token_secret']            = 'Twitter Token Secret';
    $_lang['setting_digitalsignagesocialmedia.twitter_token_secret_desc']       = '';
    $_lang['setting_digitalsignagesocialmedia.twitter_query']                   = 'Twitter query';
    $_lang['setting_digitalsignagesocialmedia.twitter_query_desc']              = 'The Twitter query, start usernames with a @ and hashtags with a #.';

    $_lang['setting_digitalsignagesocialmedia.instagram_access_token']          = 'Instagram Access Token';
    $_lang['setting_digitalsignagesocialmedia.instagram_access_token_desc']     = '';
    $_lang['setting_digitalsignagesocialmedia.instagram_query']                 = 'Instagram query';
    $_lang['setting_digitalsignagesocialmedia.instagram_query_desc']            = 'The Instagram query, start usernames with a @ and hashtags with a #.';

?>