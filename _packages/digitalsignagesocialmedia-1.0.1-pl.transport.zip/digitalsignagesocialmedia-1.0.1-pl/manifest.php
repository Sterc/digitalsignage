<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'digitalsignagesocialmedia-1.0.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '81de597d368abce3f3a9bc183f445d54',
      'native_key' => 'digitalsignagesocialmedia',
      'filename' => 'modNamespace/66b9eb4aa9ba5cd8146aefe8a590f5c3.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968c00b66aab966b9cad6fc01db0e6c4',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_id',
      'filename' => 'modSystemSetting/81a7db9c476b911763bb725e43b04cc1.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '856a6466fd444a3d5cbcfc43f6a73b2c',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_secret',
      'filename' => 'modSystemSetting/d8a914bbbf8cfcf667b1d1eed0f87467.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a93c133451ed7d625ca0c6f2ef3e445',
      'native_key' => 'digitalsignagesocialmedia.facebook_page',
      'filename' => 'modSystemSetting/b0ba4a4d62085080589f0beee0bd8ecc.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a26aebd76fb798eed2727afbe4f568a',
      'native_key' => 'digitalsignagesocialmedia.instagram_access_token',
      'filename' => 'modSystemSetting/422a2e22dc57be2e0bb1d932dcd8f06c.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7836bffe89e93396248a691a55df5b72',
      'native_key' => 'digitalsignagesocialmedia.instagram_query',
      'filename' => 'modSystemSetting/c7cfe6fa8c4563b1a87306681d503356.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79d3bdfbbdfdaeb3b10c8f78026d3f39',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_key',
      'filename' => 'modSystemSetting/1011b8e8185e52e02dfcc9ca0e9d588b.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a3a21cad18ad6c4a70308da9f88aa1a2',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_secret',
      'filename' => 'modSystemSetting/a5a475dc45381ea23649f865605e89c1.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0170b62bb89148fef14a04b290d9f040',
      'native_key' => 'digitalsignagesocialmedia.twitter_query',
      'filename' => 'modSystemSetting/a5372c24e608cba7fbe1b031e3506191.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f62cd122d536b3e6a06dc5365a0a443a',
      'native_key' => 'digitalsignagesocialmedia.twitter_token',
      'filename' => 'modSystemSetting/d65915e90fd9088552d71e967061dade.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaa84af29cc2abf6241a57953ba6c9b1',
      'native_key' => 'digitalsignagesocialmedia.twitter_token_secret',
      'filename' => 'modSystemSetting/eff67c07c77c5a6a6ca4c60028cdf867.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e40f4da142f56d36b155e23c82045414',
      'native_key' => NULL,
      'filename' => 'modCategory/4a9f39d1b53aee0f4a90b63051f35555.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
  ),
);