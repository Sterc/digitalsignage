<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'digitalsignagesocialmedia-1.0.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '95bd9cb8d1f028dcc58c92eb289eeffb',
      'native_key' => 'digitalsignagesocialmedia',
      'filename' => 'modNamespace/407b3219214dfabfe13455896ad5cc77.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44766ec7d1c8f8abdb03264e108c2cd2',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_id',
      'filename' => 'modSystemSetting/d44161eb52fe2bbedac4d52ca5311a3c.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dbf28bd0947056241c37d547fd86987c',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_secret',
      'filename' => 'modSystemSetting/43e4e8e76010792facc094e68ec6defa.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcc3be211404fec3fe0a519e94d281d2',
      'native_key' => 'digitalsignagesocialmedia.facebook_page',
      'filename' => 'modSystemSetting/93c505faf4d7206e13a62e06f6bf1d8a.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28e35820399eedd68441f16e80f02d68',
      'native_key' => 'digitalsignagesocialmedia.instagram_access_token',
      'filename' => 'modSystemSetting/10edfdddecc7874e8bc44ce98f0f3999.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67884712e7ce8a2ce8f97453dd8a5dfc',
      'native_key' => 'digitalsignagesocialmedia.instagram_query',
      'filename' => 'modSystemSetting/86d991cc0c9c35dfa0d030f9210d7627.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17ee17a433dfb1e3c8f50e42c19d8a5f',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_key',
      'filename' => 'modSystemSetting/d293de305df16b960507c2639241be79.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bcd5cd59081aafd5649796ee5397dfe',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_secret',
      'filename' => 'modSystemSetting/fa6c63f711b3b187d72b2c1785d1c5f2.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d8281c85790a82b3a25ca91dfcb0366',
      'native_key' => 'digitalsignagesocialmedia.twitter_query',
      'filename' => 'modSystemSetting/7cbace39d1c5134ca745cdd4096da758.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdf2d7f44c80e2f5665eac2286d225a7',
      'native_key' => 'digitalsignagesocialmedia.twitter_token',
      'filename' => 'modSystemSetting/ca66c26398b3cd863976d9e3643facec.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '121d85a9c2fb9e00426b3b25beb0c5b8',
      'native_key' => 'digitalsignagesocialmedia.twitter_token_secret',
      'filename' => 'modSystemSetting/70f86ba615bb2bc9412a138983030ff0.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5d3e34cdf1ed61b284990c1de4636f68',
      'native_key' => NULL,
      'filename' => 'modCategory/0dcbcda781b069824667e6cf3c218f30.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
  ),
);