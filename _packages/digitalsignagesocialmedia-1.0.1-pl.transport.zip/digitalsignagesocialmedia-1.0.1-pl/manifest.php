<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'digitalsignagesocialmedia-1.0.1-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '504d0844e1eb7229a41edbeb00627290',
      'native_key' => 'digitalsignagesocialmedia',
      'filename' => 'modNamespace/c42ace58b546db627a1face456a47a37.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e2902888c220c316e0c862931310a9b',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_id',
      'filename' => 'modSystemSetting/73c4e9d3bb32fb991aaa629161bd0ad8.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6094cb34a0d79f649dc104fa7e2f33fe',
      'native_key' => 'digitalsignagesocialmedia.facebook_app_secret',
      'filename' => 'modSystemSetting/51a23aa2b4771544cd44973344f57ee0.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c51dd6d046c30d6c95d85b48e1248bd',
      'native_key' => 'digitalsignagesocialmedia.facebook_page',
      'filename' => 'modSystemSetting/1872040c00a55312490465ab89f49c2c.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ecffdf58cd34a699c50317304ee8ce06',
      'native_key' => 'digitalsignagesocialmedia.instagram_access_token',
      'filename' => 'modSystemSetting/61181369feb1cd218601102d650f4ae4.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0e9ad8193163c5e32e6cc7f5248549f',
      'native_key' => 'digitalsignagesocialmedia.instagram_query',
      'filename' => 'modSystemSetting/1c9b078d7640a0ed632c97255ff14385.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30e044e97606c61240449f54ed6f5e77',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_key',
      'filename' => 'modSystemSetting/7a5d21e203b1ebd16c7b401806cbd48e.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a360ac9da45071de69a47cf63882b861',
      'native_key' => 'digitalsignagesocialmedia.twitter_consumer_secret',
      'filename' => 'modSystemSetting/875b3aa697f0eab52147e2f433ff4921.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc649f4253b59cedf05fca5e2ca4dffa',
      'native_key' => 'digitalsignagesocialmedia.twitter_query',
      'filename' => 'modSystemSetting/fc453af3e70770f820fc21f5e3fd6409.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bc9932db89d81ff307b91ffb23763f6',
      'native_key' => 'digitalsignagesocialmedia.twitter_token',
      'filename' => 'modSystemSetting/b6c46c600e44e41a10c4fcee9c0a99f7.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4a8f85182bd3dfddf1a9ff22fac25aa',
      'native_key' => 'digitalsignagesocialmedia.twitter_token_secret',
      'filename' => 'modSystemSetting/a1eeb437db80c50f4d383163f30c57c8.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a5448387f6bb502d5b6267930cf17575',
      'native_key' => NULL,
      'filename' => 'modCategory/93a5318ff6f35cb9e53b85b3fc9e937c.vehicle',
      'namespace' => 'digitalsignagesocialmedia',
    ),
  ),
);