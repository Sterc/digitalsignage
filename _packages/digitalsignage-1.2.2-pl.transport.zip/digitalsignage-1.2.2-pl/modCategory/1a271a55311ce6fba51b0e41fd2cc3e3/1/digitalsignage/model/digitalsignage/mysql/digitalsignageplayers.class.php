<?php

/**
 * Digital Signage
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/digitalsignageplayers.class.php';

class DigitalSignagePlayers_mysql extends DigitalSignagePlayers
{
}
