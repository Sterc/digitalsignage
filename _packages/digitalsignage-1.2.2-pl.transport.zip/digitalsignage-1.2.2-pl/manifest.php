<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7d42609a892dad6ce129a6460e129849',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/a950c89e20b30c3926cdba35934afaa0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8559423936e08ddd2ca45b817195e065',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/5d0ad0af94d9230f0448573d66850021.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '477c907efd0d5880cccc4d4710358518',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/61f46d9357e3e20425e4b8a7f226aaa6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81781287a2b66e2f896eefbb5469345c',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/ff553642254978891f101afdb2ad37c4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3bfb77b2f96d57ee3ce2e18f113ad6ec',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/247855450ed69734262e900a2b22107f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b70221ff9af2cb910d1f1c7fba8d6fc',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/0bb9b641aaa5fcc6acf4fdf789285cf9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d6c3499e62a8e230afe258e7f470b35',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/c964d3c59fe6f19289774f6c3ead93a4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4934641a0a2d69a5c264f387c9fbdad5',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/d19a67c4bc2053bf8ff53eac45f7cdb0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ea23bdb57ecb4afa5192d288e084f31',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/fbafe450e3cea65ce4d81c355e51dea1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2638a563f1621647119ba36e8a0db0e2',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/e9f72737c15af24e0e138f4cbf5979e6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '562ffb5fdb5593fc057d8a84846fcef0',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/74adfac2a452e8341ca915ab636d130b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59272220385e4fe7d86111944a6ee82b',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/7874573f8417bc490f67c7c64981abea.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73ff92362d9579162457d019ec8b3801',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/94aa1cea1515e66cec6f73e373fbc8ed.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '824439a9c077088ba0f4d651b31d2260',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/6afcdd2f5b1590127011d4ad88cb6112.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd509e0753899b54fd27b8ce180866559',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/c7e9cf048f86ecf3f56326175bb94517.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '285229b84d48ddc4f951f5167c6fb4a4',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/9de3988f7a087b0a89c0ed2a1b502546.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e83319e607dc8908fa4261ec6fac460',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/d7c1c0bcf9b95eba4d125c1d7848ac05.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89f2e9ee0a996058d04b930e8a247fd1',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/4b1b13650d8db3338df00c6fb17928f7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'de069789bc4eaf3c2425051f481e914d',
      'native_key' => NULL,
      'filename' => 'modCategory/0ec1f9be20ed6d986013c087be033a4a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cc5b512398300629fe61756d841dfe7b',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/277733ff1ac772c3c271a12551371051.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);