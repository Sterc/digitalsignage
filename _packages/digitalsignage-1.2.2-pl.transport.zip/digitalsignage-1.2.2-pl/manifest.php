<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2f401cf58a9aa0a074d1e99bda979e32',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/2dd16adfa85b45498613048dbfc4871b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '615eac81fa071fe3f188e3f0140ac32f',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/13e334bd69b2b17628993e8ccf30cad3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2f06e039c9b4861746da779dbf4c10a',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/c01281405859a9b6a846b38ac06259fd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6eb7556f306df9f8b226be17f5e20b5f',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/78d80a2c585f453a158f3a9dee622466.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ca9631429b230e6ae171b38f0643cd4',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/71a4204e0abfaed1a8476e3567bd37d3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6b781c540196bc78ac0dcdfd0f563fd',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/ef6637160569f2b7eb100a111e89f2aa.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f97e14d3a4cf52379678e344fd1debad',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/fda5cc8eab6b668a986cf577aed63e67.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f203bc56a3c94d729371ea727205514',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/29aec9b7905e41c57e15a6e908bf998f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd830447f82783d1dc25788b3021ce96a',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/3d8841f8db4c2ab2c4954c419912c9c3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04d74f41e5abbfb8898b53566451051',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/facf7d3fb58d5f8f787a08c86171a11a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00b747fb23d2c3494bde65a0b250facc',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/2e70244e886eccd2ac90e04d36c2721f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8130a59501f79403d67216db8b3f153',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/bb00f5470463a760f37476d80b7e3af4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00df91a72bae8972ce967199a1ab481e',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/803a9c8a48e47b8018ebfe656fb155ee.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb856d134571147a4d574db4b4d72c1c',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/df0e232f55109dfe76c9620e1cb7d4ce.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '497ae8c8e301e334654a9dea832732d8',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/477e82ad94728ca7b15269f3624b8b32.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2403cdfc8b4e5537b6345b57b3a2831',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/ca17caf94f979d99347a7510b3d36b4d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '362b6a7f33618bd62f5962836fe57f7a',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/10a48247887d7def4a267a4ec60b1e75.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11d3114fb56430259b7d9b2e91c58a96',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/db48a7d2514ce07f56accd61891cb120.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0c9533aceb748fcb605965544de325d8',
      'native_key' => NULL,
      'filename' => 'modCategory/1a271a55311ce6fba51b0e41fd2cc3e3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1db2c25d5a17cfb78c18699d11bd3cec',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/877a056b9cea2c40adb4001363fe371a.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);