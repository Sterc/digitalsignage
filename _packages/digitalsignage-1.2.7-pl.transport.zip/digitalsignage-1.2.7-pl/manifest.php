<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.7
Released: 2021-09-17
----------------------
- Add preview for slides

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.7-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '53711a2312ad1e1464e071e56027c3ef',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/ecbc6a3aa7d85dcc176cb8d322a5fc65.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb2af8bf362b9a68748074bb660374c4',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/6d5903c31ababbdfea4e8f99cca36d09.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f2c67200c5d2214b128012276b46d01',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/ed79fe806d536e8618855521d1caa614.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38ec9c19132402f646f5a34648b3aebb',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/61396d6c7757b3797ff53328ffd5e944.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a124c60780afd4c849aecbe90b4695c3',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/cd60e421363fe0319127df4a51c6db07.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8c5a3b99afd677345e1bfd3c8fef2e9',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/792744b9482b444fb1a034a1d8db22ae.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70db3340f3ecc7c15bc08b9858b15890',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/a8669c27e550de417af2cf86f2ef5a85.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13e80eeb61119e6768ab8ebbfa664da6',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/8ee3c383ff18efc2f64f5e643f633f26.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4cfcf71e445d2946f0033834702342a',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/2c5cb8658d7b1a9d1314c61510c488af.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43a4e32ee876e505c62168eb1f9996b5',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/cb78fdeb0e3385a80c17037fbe6aca1a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76c9951423969115a15bf37d639064a6',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/14cf16a151a24e17300707d549d3e566.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75a2123900b7611b1deeae38c311c44d',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/bf3790fe8dd78d5fc6d31fff83d63f59.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ccf64df5620d7efde7e0221735fbf7a',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/72aaea077b937ca403edb8791a60d844.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d040dcf230a95cd9eeb5c0dabaf65ea',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/3becce573ba35d5e7d2bf487fb8abc8d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b0f2004b837b30940d47c719bb05a23',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/61bed728125c6a530bfeec80ff8418dc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a2a17894958bcbb42333132cbb9cf91',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/b02a3003a52a5f6dac5f2eaf1cb4a34b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a784ede6797817fe1994be28980820cb',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/7420eb1c4af7bef57e817e30b594ae03.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0bfd28050d71c77d05283ab0e173a3',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/ad63176bfd347107cdc1c1b73dc36542.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e9edaf6385579e2e1e9fb11dbbafad8a',
      'native_key' => NULL,
      'filename' => 'modCategory/1c86ff8c57458f29116e607045d3404a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '0fbaed22a5e6c29dae004aa5c07ccdb2',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/98fc1e57c2e08c8367ab7e72a49b7c52.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);