<?php

/**
 * Digital Signage
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/digitalsignageplayersschedules.class.php';

class DigitalSignagePlayersSchedules_mysql extends DigitalSignagePlayersSchedules
{
}
