<?php

/**
 * Digital Signage
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/digitalsignageslides.class.php';

class DigitalSignageSlides_mysql extends DigitalSignageSlides
{
}
