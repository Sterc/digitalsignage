<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.6-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f886ad852069a8097c8619fd8045ba72',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/123e774a7c9e694bd65f139856433833.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63ca379783a6cf8db7806ea512827374',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/aa890290cde53e13cf810d492e2144bb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdef8cd60cc922c028a4749b9ad167cd',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/2b6f78430a19ed336db2571961a57026.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bae688a8cb66623f4fd017f567bc0e7b',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/32232edcbc26f9bac67dddf826bb7a1c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bb5ba98b936354fd622bc11755bf705',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/5f34e48e69e52c3a20b0ebcd9991a051.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '513bfb676f4cca3cd0ceb057c43385a1',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/f96b6bf9f862ccf867516b05f066d92a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29c667e94a5b6a7d0c2b0e427465cf49',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/024402db7bb093a0251396d93e4d2549.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a626615b49ee946b14f612b1a228b2',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/9184cff5bb85f10326c7831db2fb304e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42e29ea6ecb0c80ceaf4969b245a94a5',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/67636c36448d69912d16b6f1710c8a2d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c3c7c2e03fa919c85c3352e93843851',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/012b477e90a7c44168805fa8ffb324a0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de18da7e3da170e9ad5c01e5c73788fb',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/ea9a7508e0ecae786b6cdee660f26952.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fffbc0eb9588dc850bead8353c9003ec',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/6d0d4640ad908fd2ce485e076ab0c9f1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e3a30caf065c3147760f91bbbd7d0c0',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/8b1d4db84dad97b81450f29de1b2e9bc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6efc93853c66ede37f1c50f6c5e6cd03',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/1d5621ccb6d9143ba4cfe83e267ac11f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea24ae69c23953d371118d4671e8586b',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/84592421866ac5dfcf202f0ed513df10.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ed55f10e3cd20490b653feed193e10f',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/aef25b78788dc04243c49625b3dec257.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd416f286f2e64acd1733160c2f33bcd',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/e9427f5d6e9fba3e187fc07c41fd4a32.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82a867506e921551d96b9eed85556362',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/4da8130f9d7469d178a78ac9a083f9a0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c1e8513e834a605c93e19813fb43ca6f',
      'native_key' => NULL,
      'filename' => 'modCategory/2e3f8e4671baabfea80acf324eac7996.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f741e4c8de882b048611870c7877e3bc',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/b40188391ea6bd87ac2fc838db60e489.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);