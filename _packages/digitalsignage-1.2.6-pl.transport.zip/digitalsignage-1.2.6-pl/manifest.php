<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.6-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd92905bff3432ca7ad04d1ab0c76b4b1',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/deb6b74594bf37e37d49980793602c71.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7ac12b2380e2d94e697225851fc1d9e',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/094d57734854918a2a61d23d0988df7f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f660b76b0f19366adeb143f3d2c2de3',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/294046dd13584e6ed8ef8726b4b0c03d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b9d3abf9e90fea41b7043b0a17d7baf',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/125fc7f4ecfa112c4deae2b0c855c408.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e4d5a46b57c0688893aea47178630ca',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/ba79c26d5e701626521a2f50e5269607.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16b765f11c3323265b742469477f04be',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/ea4c85a84cd1dd19f2b8e88d2884afa1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c066683984842301a9b55a8ac2cb17c',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/01ec5862c8a4c6cfa5ab39e49821f898.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78e1cef19ddeaf7062f4d53b68b068a8',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/33a67d06ca6a7fbe88c6cd057ede2ca2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4766ec35eb0d1e3677cc26d86f5d9e18',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/bf914ec0212fc71b54861eff36f86b9a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4d78e63d52ea2493f796f3d075136f9',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/02df05464fe7bb85924a8238e3325aec.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0625003b198490057678724dcd9f813',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/bdca40467f08658868e4fd11ad4c5c03.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6243a345736d4a80295ce197194372e5',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/a1c00e8eba3031532c0a4daa110d8ef4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd604c439d818b4ae3ccb5d8d9a33d850',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/8d31bcb174badc5f9e2c125178b3c691.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4466036b732a69c2ff6b7118abd83b05',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/23f77101722c3642882a04e9c1443543.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '968e0568df32b0fa7cfe36c69cdb6897',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/1c6890f7ccd880ef56dcf80120dd3dfe.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d34e74189be8dcf8aaa03da06bd2538',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/e67d03f5a6a0388768abbd271bba6459.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd00a416289e5766f4a525c4609ba0b66',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/95d4788c5eea0003f949c6e4925a6280.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8921acd46e24c23df955007860d7f8f',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/2aee1ed08badc01e9db8fbb8cad465f2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1fb64db33d78376c62108d6182638428',
      'native_key' => NULL,
      'filename' => 'modCategory/78038096c8ce3faa54f562e826ccce94.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c40ccfa811cb530acbbccd17f50d6d78',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/8b18c2463ed58312976d6137c2dbb30c.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);