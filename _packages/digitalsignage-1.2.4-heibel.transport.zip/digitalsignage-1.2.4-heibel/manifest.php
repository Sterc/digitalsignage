<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.4-heibel/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b250e9398049a70b4e6d9ed069c27e40',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/e75de03049deaaf53edbba7ca587d721.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b06248cba9f5ebc22be28b51ddeece09',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/80b37a2f05e013f79af8efa4a3db1f7a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ef0bd6e7df644addf05f7cfc44b98c7',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/58d945ccf67b6b617a126093d3c5cac1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff65a4a85b0ac3a671a7e39ef1b22f43',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/78e1d83bbd4396b992e5bc4f3e915a69.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459ee7ce8464f1a30d5f71ced29dffe7',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/f3be66a9166d440dd440529770873cd2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9781fb3083c04b9150afb0554673ead',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/709473a644c5e7578536ec27a62b6012.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '199bf1fce469c02715fb4622323da8ed',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/043cea62c9f7587029d3920bc77e827e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1b8e97c63ecde34d31b189457d93ba7',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/94af6f75f91f1d06af6f0c0bfb1a62e0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1c2e5f5f9207d9621585a3a835e7d03',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/391916db48b45009635e92de9db122e3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f36ae3287b20b86ca56c216190aa34e2',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/a77098cd2e6a05305d9816cd96d014e7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7c1f456cf26f3aab506dd16eac64933',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/71839115459bf6cbdec5b71bb37b8635.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee8b9ee8b941c54cc5bdddfe6044f32f',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/78dc55704c9ca3787ec1f2bb84b0eff0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '05d4a621c9f5d1a53f83bcd9ec5c1738',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/b483ef15485e0f2ebfb954311979ff41.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da190a66e77e17d5ed3952c021a32d1c',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/58b17585dec75ab1c94b7e527ae7c964.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e44ad5b497215576c86e99f72a9d9f3',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/4dc551477c96ea94de0fbf403f1ef9cb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87ac14e6b39c289c2ff30baa37e36916',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/bf9a9fd6d9b92e61b53d0c12a885d178.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c584e3fbf07ff86a9211a8a458168f32',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/0c7be0c58877b42d792de20193e6c10a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86bcfa9f6bc2d37876374d4ee1e7610b',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/073a6c3309d4e3f109569d67473620b5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fb4feb9d8445894f10ca693fa1caf560',
      'native_key' => NULL,
      'filename' => 'modCategory/9a5dc90484a0e717c21780db38842a2f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'db5560a0d94423b1504a9dcee4546c9e',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/94692a5224510a4904aae2832e20fd09.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);