<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.4-heibel/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '17ff6318cfcc3aa7312e31dd8dae3c1f',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/0151799f1dbf2af3e3e328b2eaffcba5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9162a981a9e999a8fbbd24e80f96ea12',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/fe8db8f85286d389105c2b3aad1beeb3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d79845b25ba4287a5b06723a96e5a7',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/e5612d14ffe08310de13e3d2e7fe540c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d3887adac3a31f5164ab2f2b7285dec',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/265f95ffd83a3d135321b4fa9211fa9b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '869ad29c4116bc1274e0a26cdec3e583',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/68fd5106ee1b437e7261882e2b64a52d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd384d02987224740a414157871967da',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/7b4a5a436c07e7a5bb06c89900e97dcb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77e3f236064171eb38a463bd3b1ed22b',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/7347750df698fdb98f5a4863151e11db.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1e426ef9c8166fb143e701ee58a774e',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/ac333f132ff61f5f1d3c1a1961f1c6df.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95d8ee1a9b021abfd6a375d85c617889',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/1c588bc75acde0c100051ec1c12dfd3b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad0b6873bfd7f804187e1f1cde879796',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/e5a2a4d11c5c725a9adcb1e0a2732767.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b410baf11fd42ffac348bef3a8469c9',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/08dadb3f3a5a5e0751e65d6585ecb846.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d78b3f8c6ee6a9214a5a7e2483aad45',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/6d523b15d322f1848aafbf04500b4b92.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3254f3755695f9f26d620af3fc5b1bb9',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/1cc747437a11e00308784292b467b41c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c3d7ea0fdba0e515ee1438bd62c1df1',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/600c445850923e792d6fe010a6a81e1d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3431ef10fac506e7a0ff76bf434a79',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/453ae0a82b899a15beb10a6c3d45301d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd19b3b24898983aa726492e7194f270a',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/9e4e3b7090d58db62fbc6573bfedb086.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48c9b99090a3aa2027f50153851f1273',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/97a65c2f98bb5beabdf636e0a74d3a18.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '615be427aca85a78a58c5348f188bf33',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/2acc4eec3f882c202205be113d0bb9d7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '25288ebdb26bb1680c4acbb13364d7cf',
      'native_key' => NULL,
      'filename' => 'modCategory/ace26d6ad690ba738c02071bfa929f7c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e6146966d284b47dd3c8fb3fc86f87ae',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/7b6cce7039fee07a9587abe7010a9e4a.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);