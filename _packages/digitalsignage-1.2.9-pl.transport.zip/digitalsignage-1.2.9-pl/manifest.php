<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 3.0.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.9
Released: 2025-04-23
----------------------
- Bugfixes for MODX 3.0.0
- Updated old packages that are used in the template
- Fixed PHP Warnings

----------------------
Version: 1.2.8
Released: 2022-05-20
----------------------
- Add internal video for Media slide
- Fix date and time formatting if manager_date_format was changed
- Fix error on broadcast duplicate
- Fix entire day for players schedule

----------------------
Version: 1.2.7
Released: 2021-09-17
----------------------
- Add preview for slides

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.9-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '399976ea79755ec244493b09f0e5cc39',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/8e6163707651a7d25a2ba837631083fc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9cc9bfde85a72b5f22ec2d3b49aeb7b',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/0d8414789c0888fa963e5b9a3840baf5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61da868a66e208d8f3e9c4a35a3093a8',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/a37bb37eccdce574536deb9b7dee30e2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66133ac96bc493d6fdb3b656cc401574',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/6df61070bee1a5e093558c3ee826e28c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c33203cc97730434318395c8244603',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/48ba125a2d0f37d8746ba6c0d3127804.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31656afbbf5fbd28ec6e5f26739c8b12',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/56329fb615ab93c6ebc06084bfcf0cf5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c401a7729d9c3b584a5cc1cf7b9e6f48',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/9ea20cf3b2dfa8ee4acf1a72705e0175.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e78f43969eff31850da1cf803ad930d',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/febcc297b0e97db69d89069a352cea10.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b116c09e50763d20fdd24fcbcfc4ad07',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/ca84cf0eec0e5f4c28e8acaec0a6a41a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e42d12c1a3165ddd1d1e4dfc8192647f',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/7811288aee5339aec65d579d00674850.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e6859ea4963655396e7f0afdcaddfd1',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/9ed842f9458cffcecb8d0cf2ecafe60a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c56e3906c95434e2c79a64440d2dfc3',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/72efab1456ec93632e3bd7eab7c0e7d9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5346b455955194b8e78a4c422b96873b',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/579d63c93dca4991ef061cd7a646198c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfe15d19c5fd1b730508ad1909e86ce0',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/0523ee375465ad782ddb877f56862d64.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73df403bd84dd5e429ba7edbc235077e',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/2e7e0487a938adad759d487adf3789f6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5fe6e94a8578fec1afda110fa4c1f5b',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/ab1cac8860a33008f2064ebf987a364d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e114fa532b6d49f88ccef5c7a003e2c1',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/8e29d48bea9e7a8fee60d50beea5f4a7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de3b6bf05f7e7c07e59b1d4ba0abdf41',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/32d41f0745282b240063157d1ce1ffbc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0844d4aba59ac7c71955fff598315c4c',
      'native_key' => NULL,
      'filename' => 'modCategory/bf06e8b752411beb5d71fe37a28f77f4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '64cd20119557a41bdc0a38fece1eff06',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/e05ed7c9435188a9007f511d5b01b825.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);