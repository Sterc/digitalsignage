<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 3.0.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.10
Released: 2025-06-04
----------------------
- Fix migrating issue in installer
- Fix getting data for slideType

----------------------
Version: 1.2.9
Released: 2025-04-23
----------------------
- Bugfixes for MODX 3.0.0
- Updated old packages that are used in the template
- Fixed PHP Warnings

----------------------
Version: 1.2.8
Released: 2022-05-20
----------------------
- Add internal video for Media slide
- Fix date and time formatting if manager_date_format was changed
- Fix error on broadcast duplicate
- Fix entire day for players schedule

----------------------
Version: 1.2.7
Released: 2021-09-17
----------------------
- Add preview for slides

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.10-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f6515fa7e5569e6a75829f95a1e8541b',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/6636928e947176a1e0f7e6f276fa1a86.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50a5b798539282643db4bea63958b921',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/43bae0ca7e1d084438b7a97724fd423c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3f42c5cd16dab4016192a719fde2737',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/b5068ca4330f1f3da9400047e7dbbb8b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22cc0ad5f2255da2f64c0913ab3e420f',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/f7b46471d4efc16cb12c704653858935.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d8e1c279c7d07558925458f07c99eab',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/e92cbaf74a26629e4a66e49afbb073df.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '392b61eaa0fca10f4daeb63ac8deb2b4',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/aad131d390308fba4c973cd863929c47.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42718d7b4df30f927797145004ebf4b7',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/d833a66b8b70eed5b26980652ab454f8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '284de90639e2251fc22c5cb1817daed3',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/90c6cadade7ad7187d5ebd6ac0d436c5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61ee3383eade81f6692d05c5edb9b43c',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/b93de6bd727269b683cd8243f46bd54d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ab034a7ee162bd3abf92f101d9355c7',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/a2bd7d045f4cd9da53d6fd57efee83a8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2b3d693019233f647b3ec57a11287f3',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/f08588b2c7ce3ed686fa45c60c41d602.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '121176935961d0c288d47a364706cc09',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/a6afdfe2df488694eb22ceaa3a732322.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90ecb73cc38ff24de488228b6b2ada42',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/77e60eda867e464c8be965dfd166c285.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2f462ec9c42a926dd8aa13625ac9b27',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/6957f7de0105f01f85acb4d0085cee76.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1aaf6b648e4cd32b685edc3269e3633b',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/ff02b190e1720f321f4eec693cbd69c5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a66f693c67ea47c772a57343d6e227c',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/d411bab80add688a740e254f9fc83efe.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c86fdbee89214bd02dfac6efa1df0d37',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/3ada78d98cb2474fd34af38dfd115db1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f89a2cf46c84decaa18e2f29e8e00fb9',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/9c22c8333955af9446ab9a82ea4da20b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f193aebc562b1e9d0682c57f2ce0232c',
      'native_key' => NULL,
      'filename' => 'modCategory/4501482b8e0ab89ca9b88a5c43679205.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4c9b8aa144e129013552c30cd26e8b72',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/5e9bdce56cdc3ce8d07ec081eb67093f.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);