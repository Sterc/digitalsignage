<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignageplayers.class.php';
	
	class DigitalSignagePlayers_mysql extends DigitalSignagePlayers {}
	
?>