<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignageslides.class.php';
	
	class DigitalSignageSlides_mysql extends DigitalSignageSlides {}
	
?>