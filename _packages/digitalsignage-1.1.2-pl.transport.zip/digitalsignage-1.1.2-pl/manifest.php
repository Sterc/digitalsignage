<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.2
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bf1bfa0611b7dfe271939a83852e1dcc',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/b91afdf3c244d8bb73a388d46dc08fb9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b8e974a54a5bfb4186b41158e2712b7c',
      'native_key' => 1,
      'filename' => 'modCategory/85ab3367529675c542801805efe23b59.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46ba26895cebd64378166b15c30d65b9',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/73c07979ed9e738ea595f7316272e067.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1036804412a1d59a3c318de471715043',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/7fcc818448b6068b6ebfdb4f9cc81896.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dadc522b3cd80c60d8742ed59ddd28fc',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/4f5e474888b50f2771aa69c01ad5f2a5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2958864772d87290b0bc2fd7ed4e12c',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/e6b7630457e065b1a02187c13d1460bf.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8659b3b62cec41f9e930400af3802fae',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/7404b70536477aa44b48793f979b5bf0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b041e529d613ae82d6f2e1e3b3bee608',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/35c6893dea0221f4f09f8fde25d3b583.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4e8e31fc3d72f0fdb8a6bdf25a3937e7',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/1f1de213079c0b353035b85d02fd5a56.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);