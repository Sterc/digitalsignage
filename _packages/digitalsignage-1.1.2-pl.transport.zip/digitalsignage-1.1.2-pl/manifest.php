<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.2
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd6a46eb46a388c6f24a27797a7c69423',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/56699ca7a73b678e26b2153c11368fcb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd4e8ecd60fbd26dd63608b1695cfed3b',
      'native_key' => 1,
      'filename' => 'modCategory/a06c4860bbbd8d0b935c6a91c8ba7553.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc9375241bb562f6b8daa183a15ce756',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/8bc1c48e199fc7678fa0bdc2ccba9895.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a83a8e96729663c40c8e57dcfc77aac7',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/f5631e24e621c57bdc375e858acbdbcd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b714c02900d27c227adc0173a76249c',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/a28ec4a364b55c81114b048e320d1766.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77df7940c5e20518426916723177ab3d',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/26ef6a0306455b699e0e8b3af3c29f07.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f407f17f910a35026a8d759cf3416c5f',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/458d35c96528359d2d0ca53daad73bed.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0a05688dc7bc27ffaef98b59a9985bb',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/6da97d12d16292ab54276aa0ade980fa.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '62d3c207df7b8347b9a44a0d4ce7b81b',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/2f170bb43c33a44202fb3446c3cef874.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);