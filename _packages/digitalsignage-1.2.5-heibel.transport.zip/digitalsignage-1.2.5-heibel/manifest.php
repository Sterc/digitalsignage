<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.5-heibel/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '28873eee09f19f638bde317d6a3026fc',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/115f4e0f3e0d867adf2622eeb1bda4c5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cf88ec15d24c7017e72cd7b799108d4',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/0f2d88e1a2e253536cc86e42b07f5367.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '943c075712cc6211bf73af553724cc7e',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/1d020d423598026153e8f7a8ef892e38.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '200a3460be66b86b2afb38954b0c39f0',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/ff4c21418b3c1e1d887d1f1ae416a08a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a823f260892d3e42a81470ff383561f7',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/5958f573ee66a4b8fdecaea426cfbb94.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcf252078039ab0b478a429c0b6a3fd0',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/603b0ba141cdf9cc114a0c70c53798f7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa71becc738eeeab91605ee4cb3fee84',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/2a99e5ebb25c8260fb7a7b367f3ba006.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f836feca243445c9a02d59325441906a',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/b514d56ede41115e165a82627a1ab3d7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5b4e9413af9e0f5e62eb71bc17fb054',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/c47bdf98261c9cfe7f446d90392b008a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc2426bda4526237fecf306c4f9be70c',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/96ee840cac854c372f8a3a369b98d58a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40f38724645fe4d9ec5e26d1b81556fe',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/eaf772268e27645b55b5987fb8350b03.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36dfe04319cb055e119b3ac0ae13d12a',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/736760566c5ef56d334de20a96973f2b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d2cdc177ab09b795497ad5640f71a7c',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/083cc40eb620ac38591592861a831b5c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a393606a4a1610db494d401c3c3d33c',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/2bd4cd740a58bc45900ea993a4337732.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b328e576ecaa0bc3a3318661e4ce667c',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/bdc8b7cfa55d6f460d53185d46fa20fc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '273f35cfdb6b306c0112797bc59f2204',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/98b5c1f035c6000ca9c02b61fe123e4c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc5f1f9ee91b3ae5b400fc46d4e19ad1',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/3f413b3d48bc3836ba98a854f56a2935.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aff55fb9c589e2177a079251be287c0d',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/5c95ffa3fc20cf28a43453d3a5d88106.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd6616afb8ad4ce2ce0c802170ef22733',
      'native_key' => NULL,
      'filename' => 'modCategory/7aa9bfdf7f28810ccda936b3c96f43e6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '49a308d3b1728e334a4494b23262e160',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/5773718dca78e25f12267734957bae7e.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);