<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignagebroadcastsfeeds.class.php';
	
	class DigitalSignageBroadcastsFeeds_mysql extends DigitalSignageBroadcastsFeeds {}
	
?>