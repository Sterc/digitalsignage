<?php

    $xpdo_meta_map = array(
        'xPDOSimpleObject' => array(
            0 => 'DigitalSignageBroadcasts',
            1 => 'DigitalSignageBroadcastsFeeds',
            2 => 'DigitalSignageBroadcastsSlides',
            3 => 'DigitalSignagePlayers',
            4 => 'DigitalSignagePlayersSchedules',
            5 => 'DigitalSignageSlides',
            6 => 'DigitalSignageSlidesTypes'
        )
    );

?>