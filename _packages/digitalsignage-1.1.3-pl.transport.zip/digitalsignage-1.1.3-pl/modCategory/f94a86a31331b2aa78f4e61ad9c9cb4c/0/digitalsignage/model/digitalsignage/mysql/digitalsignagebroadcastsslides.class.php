<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignagebroadcastsslides.class.php';
	
	class DigitalSignageBroadcastsSlides_mysql extends DigitalSignageBroadcastsSlides {}
	
?>