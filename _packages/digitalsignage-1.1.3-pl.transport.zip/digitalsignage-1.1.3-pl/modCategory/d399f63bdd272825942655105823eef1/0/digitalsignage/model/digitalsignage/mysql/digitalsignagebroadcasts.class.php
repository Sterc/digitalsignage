<?php

    require_once dirname(__DIR__) . '/digitalsignagebroadcasts.class.php';

    class DigitalSignageBroadcasts_mysql extends DigitalSignageBroadcasts
    {
    }

?>