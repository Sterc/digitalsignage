<?php

    require_once dirname(__DIR__) . '/digitalsignagebroadcastsslides.class.php';

    class DigitalSignageBroadcastsSlides_mysql extends DigitalSignageBroadcastsSlides
    {
    }

?>