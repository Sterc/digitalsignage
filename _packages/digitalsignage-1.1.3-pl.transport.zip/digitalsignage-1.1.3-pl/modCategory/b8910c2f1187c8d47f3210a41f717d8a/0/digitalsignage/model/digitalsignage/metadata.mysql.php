<?php

    $xpdo_meta_map = [
        'xPDOSimpleObject' => [
            'DigitalSignageBroadcasts',
            'DigitalSignageBroadcastsFeeds',
            'DigitalSignageBroadcastsSlides',
            'DigitalSignagePlayers',
            'DigitalSignagePlayersSchedules',
            'DigitalSignageSlides',
            'DigitalSignageSlidesTypes'
        ]
    ];

?>