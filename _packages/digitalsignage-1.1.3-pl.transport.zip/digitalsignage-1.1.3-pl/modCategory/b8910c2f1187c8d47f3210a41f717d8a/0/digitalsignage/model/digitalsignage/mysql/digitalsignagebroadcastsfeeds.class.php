<?php

    require_once dirname(__DIR__) . '/digitalsignagebroadcastsfeeds.class.php';

    class DigitalSignageBroadcastsFeeds_mysql extends DigitalSignageBroadcastsFeeds
    {
    }

?>