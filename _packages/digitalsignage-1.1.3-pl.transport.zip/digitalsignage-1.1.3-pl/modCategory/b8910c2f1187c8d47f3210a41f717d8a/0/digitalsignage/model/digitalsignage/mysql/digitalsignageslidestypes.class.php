<?php

    require_once dirname(__DIR__) . '/digitalsignageslidestypes.class.php';

    class DigitalSignageSlidesTypes_mysql extends DigitalSignageSlidesTypes
    {
    }

?>