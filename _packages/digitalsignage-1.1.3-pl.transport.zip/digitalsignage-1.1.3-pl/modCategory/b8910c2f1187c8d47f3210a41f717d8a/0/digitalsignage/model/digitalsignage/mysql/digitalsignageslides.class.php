<?php

    require_once dirname(__DIR__) . '/digitalsignageslides.class.php';

    class DigitalSignageSlides_mysql extends DigitalSignageSlides
    {
    }

?>