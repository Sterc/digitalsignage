<?php

	class DigitalSignageSlidesTypes extends xPDOObject {}
	
?>