<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignagebroadcasts.class.php';
	
	class DigitalSignageBroadcasts_mysql extends DigitalSignageBroadcasts {}
	
?>