<?php

    class DigitalSignageBroadcastsSlides extends xPDOSimpleObject {}

?>