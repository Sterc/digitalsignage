<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignageplayersschedules.class.php';
	
	class DigitalSignagePlayersSchedules_mysql extends DigitalSignagePlayersSchedules {}
	
?>