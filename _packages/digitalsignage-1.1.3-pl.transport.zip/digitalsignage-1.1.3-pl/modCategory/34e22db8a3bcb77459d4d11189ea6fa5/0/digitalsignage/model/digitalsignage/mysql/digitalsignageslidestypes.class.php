<?php

	require_once dirname(dirname(__FILE__)).'/digitalsignageslidestypes.class.php';
	
	class DigitalSignageSlidesTypes_mysql extends DigitalSignageSlidesTypes {}
	
?>