<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fd45ebe62fab8331402a148ee55be99d',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/110bd626bca35eb61ec844774cb34f72.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '16cf3164e4cd285c08e23e51aa3aa0e0',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/3ee8071c16f479e3289a6851fbc40e2a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64824af723e0b9fcb8016642af25ccaf',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/449ec1d525f67bc382148e18243141ae.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17fd55a84840711821ee48b4d00e7842',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/502bb0300ac0e0a1d94db70156c18f0a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16449ba02bb4100adae7e112c2bb0cf2',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/43226bc42bb9e97054371a89e9f3f2f5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd943836ae9892fd2ad766185a30b2e0b',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/548c665d62d2e0fd2f39be95652f276b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f156a4b3d54fc92435200f27c5a90f8',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/60d123847ae8a93911bd38f11776a71d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00bbd29c95751208b837c8e629d720f0',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/43a209400d62233e1f711c5a0dbbd0ae.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fb848be484cb34cc8d4fb0aa60c5a41',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/f71c1dcb3b695d3815d5e277bdab8838.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a19d54f760a2fb5533848795b3ee19c',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/fd5b3764b13ee2cf9d6112d55aea7b4c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ae43851255ea50a03f8420cce5dd775',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/a8b81069c046d5b34a159bd648871cc0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '723323b3dd50fd09711c64de022aa07d',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/5e1aeae39782a7c19157f755af11befa.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '35507ade5f44fe49039f5ea0de2586f3',
      'native_key' => NULL,
      'filename' => 'modCategory/b8910c2f1187c8d47f3210a41f717d8a.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);