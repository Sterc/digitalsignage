<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '35f3e087394e8f47595eb123c33d92fc',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/40076ff7d6515586b164e3d62627720a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '533a528796ee7c92b09bb0707428bcca',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/59a32a6df17746db363a31f3dc9f8c97.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c8f74c1df9379807d80d114341cce0c',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/fd490628e7f36e823d1a3535fdb57c16.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee3a05b766b8cec0992e98872d468a09',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/185532ccf81af26ff866881fdf43ea0f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd80261dcc082ff215bb06484aee75a04',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/1fd5341916136c64fa9aa9c798561323.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beb8499dcbf7dfa3bde6e3d79b47f022',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/cf5ad8dbfb9b2a87521eef55bb82ab83.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1773651e464dcd530d7331d0d813da1a',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/7e084b16d298be8f216f76f0bc4cad2e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cf0dede08cf9cd6104dc249548dc986',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/29cc810847035630ab2bcee808ee4fef.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '754e30c1d443dc162e3a9ac460850e0f',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/d5d73646482afb54e9234fda3b269080.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f0686bb3cb52188e7757a9a3f88d443',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/30dd15962e192802ae72f338ebe2a20d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90c0b11420b32c2005bdb5bfcca6d3da',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/3be8eacc61894f46f18a3b33b520b3bb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c60ca966b6c375d15ab7908479c646c1',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/5819b83ef4498fd2b8cd6633f40ac9b9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '232f8ce991e4066913832bcec2fa03ba',
      'native_key' => NULL,
      'filename' => 'modCategory/390d3b7fae1ff3970c8598d8226b4d63.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);