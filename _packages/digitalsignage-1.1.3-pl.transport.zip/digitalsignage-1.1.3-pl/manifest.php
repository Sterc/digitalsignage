<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9e76943c6adfee297214c3b49740f6b8',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/434d05d309eb1d2992efac03ed337cf1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c1a69c738fd25ce7f3bd9ef9e92e22bb',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/5af60717ee288abdb0ec51c7027d8cb3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ced19a29282c4a016ec1ba181c1d3986',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/ebe74198266652aea83cf68fe1425942.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8480d7d3a8cdae77b641606daa38c886',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/12be2012bfced375dc59b8ed71922149.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccb5d8753423560e0498e97a22c934d5',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/7cdd3591a064cd357e3ab139cf4d1f63.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8263bde348c9eda405c57b7423adfbb7',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/b323373c5031ccdd3dfcaaaacf39e6c1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc64a357c7d4c90b64c3d4583cec2fe7',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/23ce61ce84ec827f71ab9109dc862ef8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed5ae0ac76406a5c678f58a9a7b7d002',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/d029770d99b1a27c8de4671ef49b7a04.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a6c548ae2dca3af927621653bd979ef',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/787ed3847d225fe91ffb26761c75ed79.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dc440254d6476810f1e70cdecae69fa',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/b394de6e11eced0f8d9da9563986259f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4ec63d9ca763aad38ef87326c4d197a',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/5889c83c375fa4fb22520a0ae8166f84.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17811255669cc866be21940a701ceeba',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/b2cbdd560fa263dd9deb80a73c182114.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c4a4d51141e430fd12385ff28bb10a63',
      'native_key' => NULL,
      'filename' => 'modCategory/f0f212221ef2a30c3a85a5002b379f21.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);