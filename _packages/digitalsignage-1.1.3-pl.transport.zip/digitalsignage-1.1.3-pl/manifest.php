<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8ad52421c8409b42e9c9cdc83f74909a',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/639fc651fbfafdc380bcc5a7037ed944.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8fe15d671641da44ffecfddf3c488716',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/aee1e6d68d17c8109d33060772a13ab4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dfd3544e918d7d542094dc31c21302a',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/169f1166589faa59f05d5fd22584dc8f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f902173dc9d060d1d881e703df8fb50',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/c360e02d3b8d8360c83f7d10e4193621.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5066c5b9d1a87ce96b70a4d8f6bdedd',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/bf3b6d49245a7c4e5c451fb8d10ed19e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce698dbec2dbc9c65ef6c4415f77e666',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/a30876c4a1b42c2c875fa106f751350b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c06cb13237ed143ae8b5d575335c0740',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/557033792325cbea106607eacbb3d42f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc7816b8cb40cfaf0847d357376513de',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/f92df9738eaa88f1daad7d57770e9e45.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1696fe96d36cabc55554dc1efe7de176',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/f1e201e2424f950fd15bbe61fbac0a5c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80cb0d71133d16f657e382d7ad333eac',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/3106c026eed732a4706d42e8a098063e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7388363541a20e004567620e42b5ef8',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/b5312465b6c9bdac3e36fc304955662d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '995d3253824af8e0bc861412b8420dd6',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/9e7539e462f725d0f0e3dc0aaa5600b0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '00f41c37008c821061a80838e84676a7',
      'native_key' => NULL,
      'filename' => 'modCategory/d399f63bdd272825942655105823eef1.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);