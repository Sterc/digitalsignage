<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1bc123fe6e18a0f95ddd6d7df43bc498',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/e59617b35394c6170c13e5a3c73158a0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a5135e349b1363c1d54cfc3a1b65a19a',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/4092d25f28b5e45ab4e39ded8f50a790.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90e149ce850f6df46d5708b7bd08f6b6',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/82fa2b27efe0f68909bc8a92a76850cd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '187fa838c8d309e604474e03ec5d1405',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/1c31e02a7a373b514099e916295854bc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faaf16f665eaa7e787b3b8d881e27f52',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/b438ed3704a2eeb024efe9a9edc9af0a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '774f6507451b857bfce69a37fda38f14',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/c871e2f11838afac5c31e0620fd52bf0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6b836ff3683027590ee18a9fbb2abb4',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/362d2fd90d042d0c3569ca0f68075f77.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d3bb06dae5ef4efeb5039611f3dbe48',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/c1a9f4385f880fd6c83536088166b124.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b0d8f877106219dd37a4bdae5eb4598',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/c4603e870a8eed7b11d8ee6347df9e39.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c30e3baff894ba6e444b932dd5869bbf',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/edb81a184338a160a9ec5dc9f06d7903.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3010dd673abae5d9da137fda3d715f3d',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/b35905034ef1d05f737747ba073a3262.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a35b26a021729cdac3d3d6abe30f3c2',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/267ba4b54a201bfb33c6878678fa37fa.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '79b8f7d0acad3afd3e57948f9bbaac6b',
      'native_key' => NULL,
      'filename' => 'modCategory/f94a86a31331b2aa78f4e61ad9c9cb4c.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);