<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2205b4c4d6685da6cbcfada46a820ec8',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/a5259ffaafabeac6262652bd469c7f07.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '89b54a76f6e9d8f911b81427ec347827',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/e648771329fbac308b47a66c96523532.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efc052250bff6bb8369cd625b15f27a9',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/f2a8b7fa44d529646f37a0f754d24a87.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd42c29846aac18a65e472b2596aaaa83',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/a729f4118bbb78dbe1c989119933923f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1716ea7e0c62de2338784a3d876c66b6',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/adacc1553cdfd3372eb619028896fc23.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea431eaeb38606ba2d0c655053842efc',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/c8ab5b75bacca58353f0cd856199a23a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91f645652c7163434112bc4f33942286',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/e4bd0681516a468409d87e8bd41cd01b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfc4d6d9b6ea64d38484633931e69584',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/d88a426c2bf967aa75e62fbddef3301e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df8b30567c505068875a19be136af65f',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/54352f6b9e882362cc397cc99dc9fae7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4bfbf3afa42fd43835dab41a9f627122',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/9fa271fa40bd27434265a0516274b4d1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2aecb05cf0c24a08cda61335eab321fc',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/a63893646035411c7dde34ad300839f9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3db8ebaa1a120b5c7b14c9772f804fed',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/eac8b4302f4017359d367bd2c9e82dcb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8226078be2633f4e773470927f561533',
      'native_key' => NULL,
      'filename' => 'modCategory/ce1e00253595a19a9f7e4fc33d373594.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);