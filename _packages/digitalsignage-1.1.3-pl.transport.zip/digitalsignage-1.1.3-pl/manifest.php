<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4c387ed5900ae77e286bae6f86126cc8',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/10f8789e212d0b576edf14c8a8226718.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '17e4bebe1d6c624c3e470df311b44320',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/f26c5fcf200a70ab87c57bc1adbf3bee.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9d37ae491ee887fc8aaba4b178336a5',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/3b69537c5870066c9b35fd2b5f286a49.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a42b89660f739b2c4b9048d2fa690fa',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/0a7f1110171824f4426dc5583cd7b32a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c70e310a5b98de707fe23196a69a948',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/14e927b92431f46769f6b921b375106f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1901c6a9e8f9b25f3e1eb855301cbfcb',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/e7df7c2a5b1150ce191d91e5f9b2d9ee.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5cd1a6bf75e5ba1e5b74fbdd0f22f1d5',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/8d2d094089a3766863e07b1afec3dfe9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd93b5b04a1f45a573be7a263f9cde100',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/723a5b11e44b5e1b7e49f77d8d71fad5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17bba2165c86828ba899a3f7679f4ab7',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/678686e136af9e2b3ac3becfc3bf0964.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1a6acbb8df57faeca5a798c5f31b486',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/c238bf10c0cc6da8367cc4bd7b4d89ff.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1ed7e263f0b79443cbc8cfe8471f632',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/924c16f17605bf8e3525916c1148e9b0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46cbe82f2d5fb22fbcecaab8e18530dc',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/d923e45226547d93122da578e8d909ed.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9643c07ab028882e7387819435e5f16d',
      'native_key' => NULL,
      'filename' => 'modCategory/59af4b4adceec0013f19510153a3d634.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);