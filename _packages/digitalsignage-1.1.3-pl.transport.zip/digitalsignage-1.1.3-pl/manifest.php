<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8b3a15d5eca70a3ce7501ee763eb6f67',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/78386ce5d4fffbd88219835953cee0dc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c12a98e6104dee13801fb94e144830df',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/7090ded66a5fbaa43c108368b806acfc.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '383552a26a07685d31bf8a90f9eebc00',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/ec1931a98f6ef187476a1cfa492ab56e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0630c20ffe3f00b773464587e50a2fd',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/31f1d71632f1c33d0b1f672dfb022ad9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '632fe384dd7cd14c0172e37924d03b55',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/bc9ef0b01ea265675e7de9fc7eab71bb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56c6330f983c00b2e7504e11d1807717',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/bd15c06df4ce077619c0105049187a44.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b5b94a1aecf7d9164aaf6d315536ccb',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/aa040cac4512e3cb0b39944e67b0963b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd769e477be595030778df4c90d2d89af',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/ccc191c9ba9fb1a5ddee0899bb2f973f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b7ccfe2e9aa6cc8ee73b5be398c4270',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/dcec79bb39053f47c8bf84a7403d12e7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7d3eed931481cd3b4b209916ff9e433',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/d49ab069eddbfb5250c9585aef4445ef.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf113a98cbadd11accc6ff54f24464bd',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/ae039b9833b3c52a66d68b51488da49b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4afeea4a9d40c27ce841d4a7757242b8',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/527f849fce5eb33e5cec1ec1c51cb8e7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'be83d7d49b3b9714c9f1295485e7bd9c',
      'native_key' => NULL,
      'filename' => 'modCategory/a6f0fb2fc61dc47ce4f393426077a775.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);