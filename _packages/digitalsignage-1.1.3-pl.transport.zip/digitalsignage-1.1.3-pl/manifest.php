<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0395b683a721facf1ee5901775e09744',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/87a82392734c7e4f65dadf8986f34431.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e2c393fa360f33ee9acefdacfc74775e',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/80ca22c16f4c928ae777816671aa297e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd074c29a4477585b807ce82b57ad3cb5',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/628a11464a092fb8a1e827f11daf63f4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43a083a32abcae22c3b2ef1d41c1287e',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/832f7b8c57d796bb8af7a3c5bdc42478.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6fd08a29c870d12f7540fcd78fc39c50',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/f4aff1256e28b5e271dea39d8edf6acd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43ce7758c9d6c0b413077aff3920a53c',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/25592fba6a3be391d6c55c672740831e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a1babf3eb56f7ad2ca5a48f288578dc',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/5b205b623a5e956c019dca52436fa4e6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fffa98fa1b4dc301267a595418d2bdb1',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/3f063292ffabf370de23b925ce6c2022.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f67f8f161ec91c6a6341a8286a92af41',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/8316a19fb280514ac9ca1985d73651b4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '573195aa281e25cfc3e2ede1055d3cd2',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/9b79e02dab6e5b27571c9e5527d0dce8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4003f565356acafd9aedf960786ef2d',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/fcf2e512aac86167cc04f298d4d03b40.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44c09799aabda8a65d712c1579da7ab9',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/db7cabead1fb761f4d9ea11dc3a71fe8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bdb5b12d755f730a0ec1a14be985614d',
      'native_key' => NULL,
      'filename' => 'modCategory/34e22db8a3bcb77459d4d11189ea6fa5.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);