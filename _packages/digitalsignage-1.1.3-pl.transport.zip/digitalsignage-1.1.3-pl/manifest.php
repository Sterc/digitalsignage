<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'eb43be0d80b9a8e835a408a0d582f8bd',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/d56735d24259601d30dd103536b28934.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '41d1c5dd5f556d6edc488459fbbb6f2c',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/82b889584e5d886ed52f2313319ac3a8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bdd28bc6112398b7eaac9324f12b385',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/ca558bd33a9f3bd9096c9d3eb6a29d87.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47e16cf64b05b287672906efa1180065',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/250ac2ab62081db28211e629d5ef396a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e31cef19409771724344ad350d4eb78c',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/8d5a036e8784aa2b043d7a49b5b4a02c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd397728a39bcaf9c703f1e3c29e3be73',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/d5fbc63382dc4e39934c3fa3b9ffe203.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9edebe853881898a10459f5916c47ae',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/36b09265d5029a76f7c53e0e539ef8ce.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cf9a559f03dd3a1d871094fd05fa7d6',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/9684ea379d43d01ba2a91f7f72929ae9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '510ca656986934c9b704710b1a626286',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/ca198900b5d3ac4b7373cca3f3be69d8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fda451eef4e705ce680313750a0ab38a',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/9598084494da92d6db8c054c8fde512a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9ec541f41cf93127bad230b0e8de6c4',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/cbc063464faa28f7df328886e35807d5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd93cc53c6fe4b08b8dbf3326c4cd3dac',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/5d088c0d504fb79e8ed45119c9050086.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '79571ab4fe7fee9d9107babcfbdd7714',
      'native_key' => NULL,
      'filename' => 'modCategory/e0a0ff26147f64be7910c19885d09cd6.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);