<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.1.3
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.1.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '73015cb07fd3ab9a65cfb1a6fa6b8c32',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/e6692f9fa58b41cc9963e3e3dd877994.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ea678276bfd17901c94fe51094f82d73',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/f2a6b1d055b9beecf3c76dae1701f2c0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beb07aeba1152685094b3b74441a4342',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/1e649a084380929c4fca86b624e5707e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ee46ddf50f01947faf312de82f3a622',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/a649206fbcd8f034494ff41bcf72bf4e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '460298167d361314c7e33eb755d282a6',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/a42dd25b3fe149ddf372703e994d107d.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ceb581653da39ff5ccd31bdc0f8673ef',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/525c5045f0ebf86ac921030966ef7c8b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fff36f5e11b0d11c40a16ccf44d18f1',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/028b16e072bcd65e3dc1f2d6e087bd9f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f8ab08024c1b51ac8905f4850f7e496',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/69a0b3ea2fd2f09480cf8e223c893333.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '864541e9a39a06d4f5c58358b1d0eaa5',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/034e112309bb1f88d621dcd00e0ead72.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3c5dceda2c27819bf47dc4c4da0c41b',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/bc6ac083fe6fb60dc7df6a3898cdc241.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a6e35eb40632c01af24b9d3fee5b5ad',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/8cb9631b02230ece5315de1924d8dbcd.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28345c5c58bcde0333c9d3d5bb0dc1aa',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/c09ff9449564bc3e709ce77512b0ab31.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '806e064d965a6af2aea4b97f82782581',
      'native_key' => NULL,
      'filename' => 'modCategory/bbf4fd49e241b9216b33b3f600bd5d02.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);