<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '721fa1162b7388514b55393c5f2881be',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/56743b7fe44de1138fdc437424f53230.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fcfe7635164cc64af85b213f764bae3c',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/d1579b194bbd86601e820ba9d67f7533.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70027ea874d1098b4daee33795a3a458',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/42f281efa781d250f739f064252c71a3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69b556bcdac7eb3ccea741f8d1d25024',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/97fd03e61304cf89738fd54d3851b14e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b3a2110051bc59fe0152a0286d809d5',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/5cd4806ca20449a8837f8c80bdf1eb33.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71205a621aa6a095403a51d796603df3',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/86d0b89b31baf1918b9902fd1ab98ab3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50c82e0cc2f5dc7f309ae1b1fc5d845b',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/d2718a65976938560a3172d49d8200ec.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f795f4bf2df804230906760d603297f8',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/7951cdc9ffe69e5c5bf93caae1a292e7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '607f2e98288aed392c9d6b471986caf4',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/447aa796cf0b9803a034a9d3346060cf.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1df9209f75d3b2e7e2571d6a694d6ab9',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/b4f755d88d3965fd233f255cc8c93326.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93189aa39cd9ba97c598b64c4cb359e9',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/30e048bc67b5bf39002285f1fb7149eb.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03013754761dfe5ace805ef1c8b4504a',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/b18e9426a0d50508b4cc9f6153ea9e36.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c38d76afc4d057e3d21f2bec8bb47b13',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/b4d106b088610e12f86cc76b33331120.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '221908a75e3eacbfc7aabfeb1d063e33',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/48e39c78249ce5326343195ccefc6ed1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf28b4318e7b5b62b7c01100acc51e53',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/cd315db801f0666b2664b735c7c665fe.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48da47339ac5ee9faa9c4bb99f3ea030',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/017a11024448b5a27413a3d75f8821b6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2246c23bfcc8bdcfe3977173f466ca0f',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/258391548cb6031f5c6999ba6e5f0345.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df2e5d075c623a014999364c0d1e0c60',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/171d6f1fe76a65157c5c9fe2854c37f3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '36d1caaf5bd7217566862488b2d6b474',
      'native_key' => NULL,
      'filename' => 'modCategory/da67b3675a4f92fd4d52f2cf38d9ac12.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cb477812f198ceb5dc0d24b8c37eb3c0',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/7099077c6717d28ab6b8df2e38efacbe.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);