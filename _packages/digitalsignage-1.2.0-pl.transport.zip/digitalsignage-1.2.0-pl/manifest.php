<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-04-23
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'adb6fb60642caaebce659b4bed1fe02d',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/d1304857380f45a9dba2b0fffdb283fa.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35815844952684394bc0a2f01d3ebb7f',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/bba2aeb3a87c3260be3449bd21cb4965.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e5c61a1e6c4afb338881dcc1b11eb18',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/095bc42ce15271302bf739f320aa1eb9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7c7ba57f7ff54b2dcc3683711dc5c51',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/b66893c88eb774b5d33999ac43939f9c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a71a01343edeed8f82fab87d14b72bc',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/1de2d74ce7f5a05e94cb152811cf9380.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ae00a71b3c5bd2dd93adc61d23db2c4',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/a06a8d310f1fa98b6454cf93e8b46e51.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d7894864aaa747ae3fcf6e00c5973dc',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/a218738adb926d981dd1e004754b9777.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b41fdb6edec589e2c2923b97449e6875',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/1387a2d6302340842a30ff61df9c25ec.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7481a4d6c07627b9be64d02ea0d35dad',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/a728797f0c1b88adde8bd1b9a8233c44.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '462ec5325b4c86445dbca8111c675fdc',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/c5d20960151b42fe947c708936caee02.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bbc5f01cccee8343675314115ac86e4',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/fdf4972bdd0e50bb5185a6b283449556.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e0edefcec7fd48a511b847ac8727674',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/4325bf2ecfbdbdb4f9b774698996d3ba.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ded38f19946f53eb15550b9ea64fa8d',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/1f47f0d235ad51034a3b0ebe3b362061.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80434f7bbf3c27f75383e45ae33b2c07',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/f1d68ca2b5383dbbbb99537f944eee80.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68c456ab54608d6785e0f650e645de87',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/261d07a3b4964fc65ed8a0d68fe93855.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2f40d4e71b84d36a9f94c4c7a9be090',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/44e315a4372d01e6f1be80d45c704f2a.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89540ca32c0d39cea918a767232a5100',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/ed0c5bf56a05e10473213d7463276007.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1ab435b4ac73e7a6a47fb5221061404',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/06909d3c4aa110d7d06e7f2f805011ab.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7de011fc88f8455cac8e25ce1d5fa670',
      'native_key' => NULL,
      'filename' => 'modCategory/a81bc53f3c8ccbfbdf99364bc45228c3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '62e1cafe75db7762906ce5faa06ac104',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/1b08ea8e1af42ffc5f7c7812c31b1ee4.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);