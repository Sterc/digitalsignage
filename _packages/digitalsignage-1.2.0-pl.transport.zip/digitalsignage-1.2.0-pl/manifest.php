<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-04-23
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f17ad5e035ce9b6d0f9e539ce776d20c',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/3e5788db999556040bbf7d6f8f3b8f05.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2d3404703f114315a7a547c50cc8ccc',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/7ebc7bcf56fa69b773bf364058e4b93f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36f9016a54217e2f0454b494d5c063aa',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/3a89cba0f3b53f87515165a87eae223e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19bc1b65b748f3ef8ae4524fd57bcc7d',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/8e149571dda084fa3e2613277a4cc82f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edc80160c4b981ee71f8a82a0bedb375',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/6d088f4d152eb3ce297d9775787d935c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6ab78fc4e8b6778588fe3254e251550',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/43725ca98e3a5e30e7909543aecf31e6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cc9762180fd629cbbc806a20ec1dddb',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/f7045acc983de0f38342b1ba112d6a50.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e402739fa2f1cc077ad14f2465eecf4',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/d0345297a4d0c15f329fa1150ff6648c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87c599fb180298a5d6ec85f8d9868d80',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/9a9540a870d45b0016802e59a90cd7be.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e86ed15428b1ff9244ffaaa945d1a9bb',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/a15acdafab387384d2fe10f11408b41b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '386057df6029e8e409729105896be6e8',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/1df215b6cb870e6d7bc6049f2e121e09.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32b5c747839d2eac61689273803451be',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/ed2e04dfe7d66dd60fa5ef40b97f23a3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45f22e8fb0c7d106c71837030363d1ff',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/e41c14755867e630d0e721caddf07407.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa5a1dea4a67432b9a60bfd97c969737',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/31d769ea8e5d4ffa9703c4890deca906.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3ba617b6e683ecf9389c5993944d7e6',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/33e0793281b0ebba090ab08ef3c95351.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f369526682efa80054c45b8cfa413b1',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/01829eda998163219e2af8c3c9323084.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02bf9d7153ae08779fb1b2e42aa6c650',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/752bd02f4f7a8217359e4af5af352cf5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9a1a1059eaaf72c73fe4da8ce5f4e26',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/e003696e64bdfe86b1a63986e3645719.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'eddd207ca04148bdf4fd38fe2fa8b842',
      'native_key' => NULL,
      'filename' => 'modCategory/38892f433f3087d07c483e407193cf93.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'df702d496c14c3ab6332530756ac0d60',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/5130f568e73519bfa183433aea3469a1.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);