<?php

/**
 * Digital Signage
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/digitalsignagebroadcasts.class.php';

class DigitalSignageBroadcasts_mysql extends DigitalSignageBroadcasts
{
}
