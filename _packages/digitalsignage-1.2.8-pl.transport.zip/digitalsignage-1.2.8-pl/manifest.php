<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.8
Released: 2022-05-20
----------------------
- Add internal video for Media slide
- Fix date and time formatting if manager_date_format was changed
- Fix error on broadcast duplicate
- Fix entire day for players schedule

----------------------
Version: 1.2.7
Released: 2021-09-17
----------------------
- Add preview for slides

----------------------
Version: 1.2.6
Released: 2021-09-16
----------------------
- Add pub_date and unpub_date for slides

----------------------
Version: 1.2.5
Released: 2021-05-13
----------------------
- New field checkboxes for URL source
- Bug fixes

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.8-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '07bd8d1f3a3b847c14e495e63dd4b34f',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/5bb5fe006022428ce5878790b8d3ff7f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc12f8237328809e75713fc67bcbca06',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/cb7740f281929ac4377090b5714810af.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '336ad5d3e11316fb0b0092ace4cc735d',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/aeaadb79d0d2cac0fd15eeed34de23ba.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a5872bc6b8e48d9dc7847d99fec7b16',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/0988d25f34660cf7e69f32c41651fea5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bfacc18e14a275d44b71552a60e09e7',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/d88c17c70691cf00a00359b698a71d42.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01dcae67e21a256a1f756242f5164dc9',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/aed366e1062f4c2e5fd60a473565bf32.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ace2b4ebb37420c7b9e97c416de2bea',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/b15573a20d76febe4791e715c27d35a3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e222c4954fa20fd5af7efc2cb36a1b3d',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/7e983ab148787c019a831d4824b51e1c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eec9685f60e048390847a371752c29be',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/9929e83b8cbb738ddbc8d2843ca7b8a8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee8671b3f8b5867c3deb103522d3c144',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/cb62127159fbf0e7aaa81c74f7bb69b1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468ef8511c6a5378d4155c03bc64b910',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/62a0369c8e7102321910bdb9e9269fb9.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f299d2ed5a651dcd9e0bdc485ab99c59',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/1957649241cd6c578ee01982039521b6.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '281281b3b648d94ce1a3b3ae5e04adb5',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/2e001f8b23a9111b41ee2b3ff92b4bf2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a967001b45785723325720f4bf489cbb',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/6826a868cd06dcbe7772e5f8c8eaf21e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a602c261ff80f7d2057ad1a4800d36bf',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/194cb1bec9ba6e0484d59dc6194764d7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dbcc8833e09d75feeec99628e56a64c',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/544ead43c999d06ee4f034c7486f996e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1614018bbec8ce562f39f05e2e7a013',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/60c0d808c88c661c1ab3e15205edb011.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5008c6603b479af2c765bae2dfa8bda0',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/2ee1ad50b631e7a318c78000ee364af3.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4aa506d671bf4c8bbadd3e67a6fb55b5',
      'native_key' => NULL,
      'filename' => 'modCategory/e019ca720fb8fc95d5d039af24a782e1.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1001a74369c753f2a2a2b815f2dd3940',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/4b6770df68a662faadd2decfdbef5b7e.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);