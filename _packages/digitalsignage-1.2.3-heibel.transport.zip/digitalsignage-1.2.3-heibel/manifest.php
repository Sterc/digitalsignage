<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '----------------------
DigitalSignage
----------------------
Version: 1.2.0
Author: Sterc
Contact: modx@sterc.nl
----------------------

## DigitalSignage
A different way to communicatie a message towards your target group is through digitalsignage. Do you know those screens at hospitals, schools and town halls which display information like the weather, sales or waiting time? Thát\'s digitalsignage! Its purpose is to serve the target group with short, informative messages. It\'s mostly used in areas where people have to wait, for example: in front of an elevator, in waiting-rooms or at an entrance.

Sterc (https://www.sterc.com) introduced this MODX Extra, it will be possible to set up a digitalsignage system in your good old MODX installation. It lets you define/manage broadcasts, slides and players. Why should you want this? As a developer, you can offer a whole new product next to your regular websites and applications, which means: a whole new market!

## Installation
1. Install the Extra on your MODX website.
2. Setup the right permissions for the users (digitalsignage and digitalsignage_admin).
3. Setup the right permissions for the digitalsignage context.
4. Make a context switch for the digitalsignage context.

When you get a JSON output in the front-end instead of the broadcast, refresh the URI\'s and try again.

## Requirements
* MODX version 2.5.0 or newer has to be installed.

## Bugs and feature requests
We greatly value your feedback, feature requests and bug reports. Please issue them on GitHub: https://github.com/Sterc/DigitalSignage/issues/new.
',
    'changelog' => '----------------------
DigitalSignage
----------------------

----------------------
Version: 1.2.0
Released: 2019-09-06
----------------------
- Bug fixes
    - Friendly URL bug
- New editor system settings
- New default template
- New slide types
    - Countdown
    - Analog clock
    - iFrame

----------------------
Version: 1.1.4
Released: 2018-05-09
----------------------
- Bug fixes

----------------------
Version: 1.1.3
Released: 2018-01-23
----------------------
- Bug fixes

----------------------
Version: 1.1.2
Released: 2017-10-24
----------------------
- Allow img tags in content field
- Bug fixes

----------------------
Version: 1.1.1
Released: 2017-09-26
----------------------
- Bug fixes

----------------------
Version: 1.1.0
Released: 2017-08-25
----------------------
- Bug fixes
- New functions
    - Player restart
    - Player synchronisation time
 - New slide
    - Buienradar slide (Netherlands only)

----------------------
Version: 1.1.0
Released: 2017-07-20
----------------------
- First release
',
    'setup-options' => 'digitalsignage-1.2.3-heibel/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '426d70d1a9742374b349183042f3448b',
      'native_key' => 'digitalsignage',
      'filename' => 'modNamespace/a8aae85d98b46ff3e4bac8e2febfbcba.vehicle',
      'namespace' => 'digitalsignage',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '199caddcd077dbc39d17caebb5c03c5f',
      'native_key' => 'digitalsignage.branding_url',
      'filename' => 'modSystemSetting/8bc44b613bce5d08e84e06e6c11f1f8c.vehicle',
      'namespace' => 'digitalsignage',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c38d91f95b50230e769b4f512068acd2',
      'native_key' => 'digitalsignage.branding_url_help',
      'filename' => 'modSystemSetting/c4217b3c64cd8122d8060e7fdb1cb74e.vehicle',
      'namespace' => 'digitalsignage',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f11abca5308ce566b6efd8a65298773d',
      'native_key' => 'digitalsignage.auto_create_sync',
      'filename' => 'modSystemSetting/c73102dd6dfc9f8516e09362f4eefe32.vehicle',
      'namespace' => 'digitalsignage',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '816234bb94b611ced496ccdac32fa684',
      'native_key' => 'digitalsignage.context',
      'filename' => 'modSystemSetting/8e47b65c5ec5be5ada2d0717f4ac1f47.vehicle',
      'namespace' => 'digitalsignage',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '617ca94f5d4578b497c90ed4d1c8c38c',
      'native_key' => 'digitalsignage.export_feed_resource',
      'filename' => 'modSystemSetting/4555dd889e109c5e16c9e88c9700dcc4.vehicle',
      'namespace' => 'digitalsignage',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39dccf52bade295186e347a71b77a24a',
      'native_key' => 'digitalsignage.export_resource',
      'filename' => 'modSystemSetting/70a3098b7dcb5902ccf32d1c9bd35702.vehicle',
      'namespace' => 'digitalsignage',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a91db7ccc3a8ce546770a6c458718321',
      'native_key' => 'digitalsignage.media_source',
      'filename' => 'modSystemSetting/042850654e8c1686c4ccec6fda24afb0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1accd7574d55220268e3ab275b0b09ea',
      'native_key' => 'digitalsignage.request_param_broadcast',
      'filename' => 'modSystemSetting/d5f5f83bf7f3ac03291071c1fe258dc7.vehicle',
      'namespace' => 'digitalsignage',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e68905dffcdb436983f73f00887fe803',
      'native_key' => 'digitalsignage.request_param_player',
      'filename' => 'modSystemSetting/ba8f61fb4bd73748acd0a221fc6fabc8.vehicle',
      'namespace' => 'digitalsignage',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6cc3b206b264d5cabd5db9fe59c9f956',
      'native_key' => 'digitalsignage.request_resource',
      'filename' => 'modSystemSetting/22e828cd6e284800fac9c96a152717e0.vehicle',
      'namespace' => 'digitalsignage',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1006ca08b441e0e9a5ee73407a49ebfb',
      'native_key' => 'digitalsignage.templates',
      'filename' => 'modSystemSetting/a44252f768bb85afd475ce25ad97b43b.vehicle',
      'namespace' => 'digitalsignage',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f18ee8aa7425f5c27685cd298e6518f1',
      'native_key' => 'digitalsignage.editor_menubar',
      'filename' => 'modSystemSetting/366493a140add5c4b7a45fc4ac56bc51.vehicle',
      'namespace' => 'digitalsignage',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc272ff96f8dc08c64c262a3af24758e',
      'native_key' => 'digitalsignage.editor_plugins',
      'filename' => 'modSystemSetting/4a2bd726e4989d360611849e1313cd09.vehicle',
      'namespace' => 'digitalsignage',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca8489c08aa760a9d7e1d0ba6a0fe199',
      'native_key' => 'digitalsignage.editor_statusbar',
      'filename' => 'modSystemSetting/27043b5f0d72755da5ab960f6ba08ed2.vehicle',
      'namespace' => 'digitalsignage',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af966049092437086de2b3cc6eb87f7c',
      'native_key' => 'digitalsignage.editor_toolbar1',
      'filename' => 'modSystemSetting/5e78d6f9d40ac8f6cb1e413264bfb78f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc367277130739e8a15a446457bdf64d',
      'native_key' => 'digitalsignage.editor_toolbar2',
      'filename' => 'modSystemSetting/f24815298db76ea095980543c04da6ad.vehicle',
      'namespace' => 'digitalsignage',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '569e20ac99e4092783bcaad063604b30',
      'native_key' => 'digitalsignage.editor_toolbar3',
      'filename' => 'modSystemSetting/5eec0fae9cc2b88a6d2ac463e3d72eb5.vehicle',
      'namespace' => 'digitalsignage',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '158e22585863e19d5460de0fc477306a',
      'native_key' => NULL,
      'filename' => 'modCategory/3f04cca7d619dd2c5803397cea4f939f.vehicle',
      'namespace' => 'digitalsignage',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd3746f36d0e0742db0cb5a8ce6ffec8f',
      'native_key' => 'digitalsignage',
      'filename' => 'modMenu/2e76f355809bee8a2f39fb34f0922dc4.vehicle',
      'namespace' => 'digitalsignage',
    ),
  ),
);