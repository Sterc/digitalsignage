<?php

/**
 * Digital Signage
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <oenetjeerd@sterc.nl>
 */

require_once dirname(__DIR__) . '/digitalsignagebroadcastsslides.class.php';

class DigitalSignageBroadcastsSlides_mysql extends DigitalSignageBroadcastsSlides
{
}
